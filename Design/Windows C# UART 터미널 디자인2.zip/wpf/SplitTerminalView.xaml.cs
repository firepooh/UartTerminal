using System.Windows;
using System.Windows.Controls;

namespace UartTerminal
{
    /// <summary>
    /// Split container for multiple terminal panes.
    /// Call SetLayout(...) from the tab-bar layout toggle in the mockup.
    /// </summary>
    public partial class SplitTerminalView : UserControl
    {
        public enum Layout { Single, VerticalSplit, HorizontalSplit }

        public SplitTerminalView()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Rebuilds the Grid definitions and re-slots the panes + splitter
        /// so the same three children work for every layout.
        /// </summary>
        public void SetLayout(Layout layout)
        {
            Root.ColumnDefinitions.Clear();
            Root.RowDefinitions.Clear();

            // Grab the three children (pane1, splitter, pane2) by index.
            var pane1    = (UIElement)Root.Children[0];
            var splitter = (GridSplitter)Root.Children[1];
            var pane2    = (UIElement)Root.Children[2];

            switch (layout)
            {
                case Layout.Single:
                    Root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    Grid.SetColumn(pane1, 0);
                    splitter.Visibility = Visibility.Collapsed;
                    pane2.Visibility = Visibility.Collapsed;
                    break;

                case Layout.VerticalSplit: // side by side
                    Root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    Root.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    Root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    Grid.SetColumn(pane1, 0);
                    Grid.SetColumn(splitter, 1);
                    Grid.SetColumn(pane2, 2);
                    splitter.Width = 1;
                    splitter.Height = double.NaN;
                    splitter.HorizontalAlignment = HorizontalAlignment.Stretch;
                    splitter.VerticalAlignment = VerticalAlignment.Stretch;
                    splitter.Visibility = Visibility.Visible;
                    pane2.Visibility = Visibility.Visible;
                    break;

                case Layout.HorizontalSplit: // stacked
                    Root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                    Root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                    Root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
                    Grid.SetColumn(pane1, 0); Grid.SetRow(pane1, 0);
                    Grid.SetColumn(splitter, 0); Grid.SetRow(splitter, 1);
                    Grid.SetColumn(pane2, 0); Grid.SetRow(pane2, 2);
                    splitter.Height = 1;
                    splitter.Width = double.NaN;
                    splitter.HorizontalAlignment = HorizontalAlignment.Stretch;
                    splitter.VerticalAlignment = VerticalAlignment.Stretch;
                    splitter.Visibility = Visibility.Visible;
                    pane2.Visibility = Visibility.Visible;
                    break;
            }
        }
    }
}
