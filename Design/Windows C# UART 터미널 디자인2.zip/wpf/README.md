# UartTerminal — WPF Dark Theme

Drop-in dark styling for your C#/WPF UART terminal. Matches the approved mockup:
COM port tabs, field-style command input, and a segmented status bar.

## Files
- `App.xaml` — merges the theme dictionary.
- `Themes/DarkTheme.xaml` — colors, brushes, fonts, and all control styles.
- `MainWindow.xaml` — full window layout (menu · tabs · terminal · input · status).
- `MainWindow.xaml.cs` — colorized `AppendLog(line)` + send handling.
- `SplitTerminalView.xaml` / `.xaml.cs` — vertical/horizontal split of multiple panes.
- `Themes/SplitIcons.xaml` — quick split-layout icons (single / vertical / horizontal / 2×2 grid) + a ready `SplitToggle` ToggleButton style.
- `UartTerminal.ico` — app icon.

## How to use

1. Copy `Themes/DarkTheme.xaml` into your project and reference it from `App.xaml`
   (see the `MergedDictionaries` block).
2. Use `MainWindow.xaml` as-is, or copy the style keys onto your existing controls:
   - Tabs: `Style="{StaticResource ComTabControl}"` +
     `ItemContainerStyle="{StaticResource ComTabItem}"`
   - Input: `Style="{StaticResource CommandInput}"`, `SendButton`, `ChipButton`
   - Status: `StatusBarPanel`, `StatusText`, `StatusDivider`
3. Set the window/app icon: `Icon="UartTerminal.ico"` on `<Window>` and
   `<ApplicationIcon>UartTerminal.ico</ApplicationIcon>` in the `.csproj`.
4. Feed device data into `AppendLog(line)` from your `SerialPort.DataReceived`
   handler — remember to marshal onto the UI thread:

   ```csharp
   _port.DataReceived += (s, e) =>
   {
       string chunk = _port.ReadExisting();
       Dispatcher.Invoke(() => AppendLog(chunk));
   };
   ```

## Fonts
The theme asks for **Cascadia Code** (bundled with Windows Terminal / Visual Studio)
and falls back to **Consolas**. Install Cascadia Code for the exact look, or change
`MonoFont` in `DarkTheme.xaml`.

## Split view (multiple tabs at once)
`SplitTerminalView` shows two (or more) ports side by side or stacked, matching the
layout toggle in the mockup's tab bar. WPF has no split container, so it uses a
`Grid` + `GridSplitter`; `SetLayout(Layout.Single | VerticalSplit | HorizontalSplit)`
rewrites the row/column definitions at runtime and drag-resizes via the splitter.

Wire the three toggle buttons to it:
```csharp
_split.SetLayout(SplitTerminalView.Layout.VerticalSplit);   // side by side
_split.SetLayout(SplitTerminalView.Layout.HorizontalSplit); // stacked
_split.SetLayout(SplitTerminalView.Layout.Single);          // one pane
```
For 3+ panes, add more `ColumnDefinition`/`RowDefinition` + `GridSplitter` pairs, or
nest split views. Each pane is a `RichTextBox` fed by the same `AppendLog` logic.

## Quick split icons (toolbar)
`Themes/SplitIcons.xaml` gives 16×16 outline geometries — `Ic.Single`, `Ic.SplitV`,
`Ic.SplitH`, `Ic.Grid` — plus a `SplitToggle` ToggleButton style and `SplitToolbar`
pill, matching the mockup's toggle group. Drop them into the tab bar:

```xml
<Border Style="{StaticResource SplitToolbar}">
  <StackPanel Orientation="Horizontal">
    <ToggleButton Style="{StaticResource SplitToggle}" Tag="{StaticResource Ic.Single}"
                  Click="Layout_Single" ToolTip="Single view"/>
    <ToggleButton Style="{StaticResource SplitToggle}" Tag="{StaticResource Ic.SplitV}"
                  Click="Layout_V" ToolTip="Split vertically"/>
    <ToggleButton Style="{StaticResource SplitToggle}" Tag="{StaticResource Ic.SplitH}"
                  Click="Layout_H" ToolTip="Split horizontally"/>
    <ToggleButton Style="{StaticResource SplitToggle}" Tag="{StaticResource Ic.Grid}"
                  Click="Layout_Grid" ToolTip="Grid (2×2)"/>
  </StackPanel>
</Border>
```
The geometries are stroked (outlines), so they stay crisp at any DPI — no PNG assets
needed. `SetLayout` supports `Grid2x2` for the 2×2 view.

## Notes
- Colors are GitHub-dark inspired; edit them in one place (the `<Color>` block in
  `DarkTheme.xaml`).
- The log coloring in `AppendLog` keys off the `I/W/E (timestamp) module:` header
  and highlights TX/RX. Adjust the `Header` regex to match your firmware format.
- For fully custom window chrome, set `WindowStyle="None"` +
  `AllowsTransparency="True"` and build the title bar as a `Border` (the mockup
  shows one). Otherwise keep the native title bar as configured.
