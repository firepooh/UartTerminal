using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace UartTerminal
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // ---------------------------------------------------------
        // Log-level colors (match DarkTheme.xaml)
        // ---------------------------------------------------------
        static readonly Brush Ts     = Brush(0x6B, 0x76, 0x88);
        static readonly Brush Info   = Brush(0x3F, 0xB9, 0x50);
        static readonly Brush Warn   = Brush(0xD2, 0x99, 0x22);
        static readonly Brush Error  = Brush(0xF8, 0x51, 0x49);
        static readonly Brush Key    = Brush(0x58, 0xA6, 0xFF);
        static readonly Brush Muted  = Brush(0x8B, 0x97, 0xA8);
        static readonly Brush State  = Brush(0xF0, 0x88, 0x3E);
        static readonly Brush Txt    = Brush(0xE6, 0xED, 0xF5);
        static readonly Brush TxCol  = Brush(0x3F, 0xB9, 0x50);
        static readonly Brush RxCol  = Brush(0x58, 0xA6, 0xFF);

        static SolidColorBrush Brush(byte r, byte g, byte b) =>
            new SolidColorBrush(Color.FromRgb(r, g, b));

        // Regex to pull the leading "I (03:14:00.215) module:" header.
        static readonly Regex Header =
            new Regex(@"^(?<lvl>[IWE])\s\((?<ts>[\d:.]+)\)\s(?<mod>\w+):", RegexOptions.Compiled);

        /// <summary>
        /// Append a raw device line, colorized by log level and token.
        /// Call this from your SerialPort.DataReceived handler
        /// (marshal to the UI thread with Dispatcher.Invoke).
        /// </summary>
        public void AppendLog(string line)
        {
            var p = new Paragraph { Margin = new Thickness(0) };

            var m = Header.Match(line);
            if (m.Success)
            {
                Brush lvlBrush = m.Groups["lvl"].Value switch
                {
                    "W" => Warn,
                    "E" => Error,
                    _   => Info,
                };
                p.Inlines.Add(Run(m.Groups["lvl"].Value + " ", lvlBrush, bold: true));
                p.Inlines.Add(Run("(" + m.Groups["ts"].Value + ") ", Ts));
                p.Inlines.Add(Run(m.Groups["mod"].Value + ": ", Key));

                string rest = line.Substring(m.Length).Trim();

                // Highlight TX / RX direction if present.
                if (rest.Contains("Sent"))
                    p.Inlines.Add(Run("TX ", TxCol, bold: true));
                else if (rest.Contains("Received"))
                    p.Inlines.Add(Run("RX ", RxCol, bold: true));

                p.Inlines.Add(Run(rest, Muted));
            }
            else
            {
                p.Inlines.Add(Run(line, Txt));
            }

            LogView.Document.Blocks.Add(p);

            // Auto-scroll to newest.
            LogView.ScrollToEnd();
        }

        static Run Run(string text, Brush brush, bool bold = false) =>
            new Run(text)
            {
                Foreground = brush,
                FontWeight = bold ? FontWeights.Bold : FontWeights.Normal,
            };

        // ---------------------------------------------------------
        // Input handling
        // ---------------------------------------------------------
        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                Send();
                e.Handled = true;
            }
        }

        private void Send_Click(object sender, RoutedEventArgs e) => Send();

        private void Send()
        {
            string cmd = InputBox.Text;
            if (string.IsNullOrEmpty(cmd)) return;

            // TODO: write to your SerialPort here, e.g.
            //   _port.Write(cmd + "\r\n");
            AppendLog("> " + cmd);
            InputBox.Clear();
        }
    }
}
